# 微网电力调控策略（C 题）：支撑材料说明

本包为参赛论文的支撑材料，包含论文源码、五份规定结果工作簿、全部源程序、图表与
AI 工具使用详情。包内所有文件均不含可识别参赛者身份、学校或赛区的信息。

## 目录结构

```text
main.tex                       论文完整源码（论文 main.pdf 单独提交）
AI工具使用详情.pdf / .tex       AI 工具使用详情，对应论文参考文献前的“AI 工具使用声明”
README.md                      本说明

结果/                           五份规定结果工作簿
  result1.xlsx                  问题 1
  result2.xlsx                  问题 2
  result3.xlsx                  问题 3
  result4-2.xlsx                问题 4，沿用问题 2 的模型
  result4-3.xlsx                问题 4，沿用问题 3 的模型
  补充/                         当天价格完全已知的对照，非规定结果
    补充_价格已知_result4-2.xlsx
    补充_价格已知_result4-3.xlsx

code/                           源程序，论文附录 B 逐份列出
  model.py                      数据读取、预测、场景构造、稀疏线性规划、执行反馈
  run_experiments.py            四问主模型与全部对照实验
  export_results.py             生成结果/下的工作簿
  check_model.py                功率、SOC、费用与边界检查
  diagnostics.py                预报误差、场景配对与储能反馈诊断
  refinements.py                终端价值、费用选型与调整门控实验
  refinement_evidence.py        上述实验的表格与数值宏
  polish_presentation.py        分析表标题与描述统计
  paper_figures.py              论文图组与源数据核验
  review_experiments.py         风险权重、效率与库存诊断实验
  review_figures.py             诊断图组
  emergency_surface.py          紧急购电曲面图
  review_oracle_execution.py    当日完全预知执行的上界计算
  scientific_style.py           绘图公共样式
  verify_consistency.py         摘要、正文、工作簿与结果数组独立对账
  requirements.txt              依赖清单

results/                        计算结果与核验记录（JSON／CSV）
tables/                         论文引用的表格（LaTeX 源码）
figures/                        论文插图（PDF）
```

## 结果文件口径

- `结果/` 五份工作簿为题面规定结果，文件名与工作表名均与附件 5 模板一致（时间标签
  的处理见论文附录 A.3）。
- `结果/补充/` 两份工作簿是“当天价格完全已知”的对照，**不得与规定工作簿混填**。
- 全年工作簿“计划购电量”“调整购电量”中的“全天购电费”均为当日实际总费用（含紧急
  购电费），两列重复展示同一笔费用，**不得相加**；逐日费用拆分见
  `results/daily_summary.csv`。

## 复现

环境：Python 3.12.14、NumPy 2.5.3、SciPy 1.18.1，另需 openpyxl、Matplotlib 与
XeLaTeX。本包不含赛题原始附件与中间 NPZ 缓存，复现时需自备附件目录，并把下面命令
中的 `DATA` 替换为该目录（例如 `题目`）。

```text
python -m pip install -r code/requirements.txt
python code/run_experiments.py --data DATA
python code/export_results.py --data DATA
python code/check_model.py --data DATA
python code/diagnostics.py --data DATA
python code/make_evidence.py
python code/refinements.py --data DATA
python code/refinement_evidence.py
python code/polish_presentation.py
python code/paper_figures.py
python code/review_experiments.py
python code/review_figures.py
python code/emergency_surface.py
python code/review_oracle_execution.py
python code/verify_consistency.py
xelatex -interaction=nonstopmode main.tex
xelatex -interaction=nonstopmode main.tex
xelatex -interaction=nonstopmode AI工具使用详情.tex
```

只重绘图形时，保留 `results/` 中已有数组，运行相应绘图脚本即可；`verify_consistency.py`
只读取既有结果，不产生新数据。
